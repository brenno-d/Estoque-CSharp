﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace estoque
{
    public partial class frmUsuario : Form
    {
        public frmUsuario()
        {
            InitializeComponent();
        }

        private void frmUsuario_Load(object sender, EventArgs e)
        {
            // TODO: esta linha de código carrega dados na tabela 'dbEstoqueDataSet.tb_usuarios'. Você pode movê-la ou removê-la conforme necessário.
            this.tb_usuariosTableAdapter.Fill(this.dbEstoqueDataSet.tb_usuarios);

        }

        private void tb_usuariosBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.tb_usuariosBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.dbEstoqueDataSet);

        }
    }
}
