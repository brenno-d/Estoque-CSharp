﻿namespace ProjetoEstoque
{


    partial class bancoEstoqueDataSet1
    {
    }
}

namespace ProjetoEstoque.bancoEstoqueDataSet1TableAdapters {
    
    
    public partial class tb_usuarioTableAdapter {
    }
}
