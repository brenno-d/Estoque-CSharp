﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjetoEstoque
{
    public partial class frmPesquisaUsuario : Form
    {
        private int codigo;
        public frmPesquisaUsuario()
        {
            InitializeComponent();
        }
        public int getCodigo()
        {
            return codigo;
        }
        private void tb_usuarioBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.tb_usuarioBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.bancoEstoqueDataSet1);

        }

        private void frmPesquisaUsuario_Load(object sender, EventArgs e)
        {
            // TODO: esta linha de código carrega dados na tabela 'bancoEstoqueDataSet1.tb_usuario'. Você pode movê-la ou removê-la conforme necessário.
            this.tb_usuarioTableAdapter.Fill(this.bancoEstoqueDataSet1.tb_usuario);

        }

        private void btnPesquisar_Click(object sender, EventArgs e)
        {
            if(txtNome.Text == "")
            {
                this.tb_usuarioTableAdapter.Fill(this.bancoEstoqueDataSet1.tb_usuario);
            }
            else
            {
                Select * from tb_usuario WHERE nm_usuario = txtNome.Text;
            }
        }

        private void tb_usuarioDataGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            codigo = Convert.ToInt32(tb_usuarioDataGridView.CurrentRow.Cells[0].Value); 
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            codigo = 0;
            Close();
        }
    }
}
